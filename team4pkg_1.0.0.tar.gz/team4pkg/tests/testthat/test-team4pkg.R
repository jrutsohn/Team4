test_that("multiplication works", {
  expect_equal(2 * 2, 4)
})
